<?php
try {
    $host = 'localhost';
    $port = 5432;
    $dbname = 'seniorsApp_db'; 
    $user = 'postgres';       
    $password = 'piyush29';    

    $pdo = new PDO("pgsql:host=$host;port=$port;dbname=$dbname", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // echo "Connexion réussie";
} catch (PDOException $e) {
    echo "Erreur de connexion : " . $e->getMessage();
    die();
}
?>
