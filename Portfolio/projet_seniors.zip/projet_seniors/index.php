<?php
// index.php – point d’entrée principal
// Redirige automatiquement vers la page de connexion / inscription

header('Location: view/authentification.php');
exit();
?>
