<?php
session_start();
require_once(__DIR__ . '/../config/bdd.php');

if (!isset($_SESSION['id_utilisateur']) || $_SESSION['role'] !== 'admin') {
    header('Location: authentification.php');
    exit();
}

$stmt = $pdo->query("SELECT * FROM evenement ORDER BY date_heure ASC");
$evenements = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des événements</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<div class="container">
    <div class="box">
        <h2>📅 Événements en cours</h2>

        <!-- 🔘 Bouton de création d’événement -->
        <a href="form_ajouter_evenement.php" class="btn">➕ Créer un événement</a>

        <!-- ✅ Affichage des messages -->
        <?php if (isset($_GET['success']) && $_GET['success'] === 'suppression'): ?>
            <div class="success-message">✅ Événement supprimé avec succès.</div>
        <?php elseif (isset($_GET['erreur']) && $_GET['erreur'] === 'idmanquant'): ?>
            <div class="error-message">❌ ID manquant.</div>
        <?php elseif (isset($_GET['erreur']) && $_GET['erreur'] === 'introuvable'): ?>
            <div class="error-message">❌ Événement introuvable.</div>
        <?php endif; ?>

        <!-- 🗓️ Liste des événements -->
        <?php foreach ($evenements as $e): ?>
            <div class="event-card" style="margin-bottom: 20px;">
                <strong><?= htmlspecialchars($e['titre']) ?></strong><br>
                <?= htmlspecialchars($e['description']) ?><br>
                🗓️ <?= $e['date_heure'] ?> à <?= htmlspecialchars($e['lieu']) ?><br>
                Participants max : <?= $e['nb_max_participants'] ?><br>

                <a href="participants_evenement.php?id_evenement=<?= $e['id_evenement'] ?>" class="nav-link">👥 Voir participants</a>

                <form action="../controller/supprimer_evenements.php" method="POST" style="display:inline;" onsubmit="return confirm('Supprimer cet événement ?');">
                    <input type="hidden" name="id_evenement" value="<?= $e['id_evenement'] ?>">
                    <input type="submit" value="❌ Supprimer">
                </form>
            </div>
        <?php endforeach; ?>

        <a href="espace_admin.php" class="btn-deconnexion">⬅ Retour à l’accueil admin</a>
    </div>
</div>
</body>
</html>
