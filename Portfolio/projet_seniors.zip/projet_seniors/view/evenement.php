<?php
session_start();
require_once(__DIR__ . '/../config/bdd.php');

if (!isset($_SESSION['id_utilisateur']) || $_SESSION['role'] !== 'senior') {
    header('Location: authentification.php');
    exit();
}

$id_utilisateur = $_SESSION['id_utilisateur'];

// Récupération de tous les événements
$stmt = $pdo->query("SELECT * FROM evenement ORDER BY date_heure ASC");
$evenements = $stmt->fetchAll();

// Récupération des participations de l’utilisateur
$participations = $pdo->prepare("SELECT id_evenement FROM participation WHERE id_utilisateur = :id");
$participations->execute(['id' => $id_utilisateur]);
$ids = $participations->fetchAll(PDO::FETCH_COLUMN);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Événements</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<div class="container">
    <div class="box">
        <h2>📅 Liste des événements</h2>

        <?php if (isset($_GET['success'])): ?>
            <div class="success-message">✅ Inscription réussie !</div>
        <?php elseif (isset($_GET['erreur']) && $_GET['erreur'] === 'deja_inscrit'): ?>
            <div class="error-message">⚠️ Vous êtes déjà inscrit à cet événement.</div>
        <?php elseif (isset($_GET['erreur']) && $_GET['erreur'] === 'manquant'): ?>
            <div class="error-message">❌ ID événement manquant.</div>
        <?php endif; ?>

        <?php foreach ($evenements as $e): ?>
            <div class="event-card" style="margin-bottom: 20px;">
                <strong><?= htmlspecialchars($e['titre']) ?></strong><br>
                <?= htmlspecialchars($e['description']) ?><br>
                🗓️ <?= $e['date_heure'] ?> à <?= htmlspecialchars($e['lieu']) ?><br>
                Max participants : <?= $e['nb_max_participants'] ?><br>

                <?php if (in_array($e['id_evenement'], $ids)): ?>
                    <p class="success-message">✔️ Vous êtes déjà inscrit</p>
                <?php else: ?>
                    <form action="../controller/inscription_evenement.php" method="POST" style="margin-top: 10px;">
                        <input type="hidden" name="id_evenement" value="<?= $e['id_evenement'] ?>">
                        <input type="submit" value="S'inscrire">
                    </form>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>

        <a href="espace_senior.php" class="btn-deconnexion">⬅ Retour</a>
    </div>
</div>
</body>
</html>
