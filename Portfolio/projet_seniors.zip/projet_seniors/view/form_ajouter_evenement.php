<?php
session_start();
if (!isset($_SESSION['id_utilisateur']) || $_SESSION['role'] !== 'admin') {
    header('Location: authentification.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Créer un événement</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<div class="container">
    <div class="box">
        <h2>Créer un événement</h2>
        <form action="../controller/ajouter_evenement.php" method="post">
            <label>Titre :</label>
            <input type="text" name="titre" required>

            <label>Description :</label>
            <textarea name="description" required></textarea>

            <label>Lieu :</label>
            <input type="text" name="lieu" required>

            <label>Date et heure :</label>
            <input type="datetime-local" name="date_heure" required>

            <label>Type :</label>
            <select name="type" required>
                <option value="balade">Balade</option>
                <option value="cinéma">Cinéma</option>
                <option value="sport">Sport</option>
                <option value="culture">Culture</option>
                <option value="autre">Autre</option>
            </select>

            <label>Places disponibles :</label>
            <input type="number" name="nb_max_participants" required min="1">

            <button type="submit" class="btn">Créer l’événement</button>
        </form>
        <a href="admin_evenements.php" class="btn-deconnexion">⬅ Retour</a>
    </div>
</div>
</body>
</html>
