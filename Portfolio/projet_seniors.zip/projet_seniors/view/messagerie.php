<?php
session_start();
require_once(__DIR__ . '/../config/bdd.php');
require_once(__DIR__ . '/../model/utilisateur.php');

if (!isset($_SESSION['id_utilisateur']) || $_SESSION['role'] !== 'senior') {
    header('Location: authentification.php');
    exit();
}

$id_utilisateur = $_SESSION['id_utilisateur'];

// Liste des autres seniors avec statut
$stmt = $pdo->prepare("SELECT id_utilisateur, prenom, statut FROM utilisateur WHERE role = 'senior' AND id_utilisateur != :id");
$stmt->execute(['id' => $id_utilisateur]);
$utilisateurs = $stmt->fetchAll();

// Récupération des messages (émis ou reçus)
$stmt = $pdo->prepare("
    SELECT m.*, u1.prenom AS emetteur, u2.prenom AS destinataire
    FROM message m
    JOIN utilisateur u1 ON m.id_emetteur = u1.id_utilisateur
    JOIN utilisateur u2 ON m.id_destinataire = u2.id_utilisateur
    WHERE m.id_emetteur = :id OR m.id_destinataire = :id
    ORDER BY m.date_heure DESC
");
$stmt->execute(['id' => $id_utilisateur]);
$messages = $stmt->fetchAll();

// Statut actuel de l'utilisateur
$statut = getStatut($pdo, $id_utilisateur);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Messagerie</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<div class="container">
    <div class="box">
        <h2>💬 Envoyer un message</h2>

        <!-- Formulaire pour changer de statut -->
        <form action="../controller/modifier_statut.php" method="POST" style="margin-bottom:15px;">
            <label for="statut">Mon statut :</label>
            <select name="statut" id="statut" onchange="this.form.submit()">
                <option value="en ligne" <?= $statut === 'en ligne' ? 'selected' : '' ?>>🟢 En ligne</option>
                <option value="absent" <?= $statut === 'absent' ? 'selected' : '' ?>>🟡 Absent</option>
                <option value="ne pas déranger" <?= $statut === 'ne pas déranger' ? 'selected' : '' ?>>🔴 Ne pas déranger</option>
            </select>
        </form>

        <?php if (isset($_GET['success'])): ?>
            <div class="success-message">✅ Message envoyé !</div>
        <?php elseif (isset($_GET['erreur']) && $_GET['erreur'] === 'champ_vide'): ?>
            <div class="error-message">❌ Tous les champs sont obligatoires.</div>
        <?php elseif (isset($_GET['erreur']) && $_GET['erreur'] === 'destinataire'): ?>
            <div class="error-message">❌ Destinataire invalide.</div>
        <?php endif; ?>

        <!-- Formulaire d'envoi de message -->
        <form action="../controller/envoyer_message.php" method="POST">
            <label>Destinataire :</label>
            <select name="id_destinataire" required>
                <?php foreach ($utilisateurs as $u): ?>
                    <option value="<?= $u['id_utilisateur'] ?>">
                        <?= htmlspecialchars($u['prenom']) ?> -
                        <?php if ($u['statut'] === 'en ligne'): ?>
                            🟢 En ligne
                        <?php elseif ($u['statut'] === 'absent'): ?>
                            🟡 Absent
                        <?php elseif ($u['statut'] === 'ne pas déranger'): ?>
                            🔴 Ne pas déranger
                        <?php else: ?>
                            ⚪ Inconnu
                        <?php endif; ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <label>Message :</label>
            <textarea name="contenu" rows="4" required></textarea>

            <input type="submit" value="Envoyer">
        </form>
    </div>

    <div class="box">
        <h2>📨 Historique des messages</h2>
        <?php if (empty($messages)): ?>
            <p>Vous n’avez pas encore échangé de messages.</p>
        <?php else: ?>
            <?php foreach ($messages as $msg): ?>
                <div class="message">
                    <strong><?= htmlspecialchars($msg['emetteur']) ?> → <?= htmlspecialchars($msg['destinataire']) ?></strong><br>
                    <?= htmlspecialchars($msg['contenu']) ?><br>
                    <em class="date-message"><?= $msg['date_heure'] ?></em>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
        <a href="espace_senior.php" class="btn-deconnexion">⬅ Retour</a>
    </div>
</div>
</body>
</html>
