<?php
session_start();
if (!isset($_SESSION['id_utilisateur']) || $_SESSION['role'] !== 'admin') {
    header('Location: authentification.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Espace Admin</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
    <div class="container">
        <div class="box">
            <h1>Espace Administrateur 👑</h1>

            <ul>
                <li><a class="nav-link" href="admin_utilisateurs.php">👥 Gérer les utilisateurs</a></li>
                <li><a class="nav-link" href="admin_evenements.php">📅 Gérer les événements</a></li>
            </ul>

            <form action="deconnexion.php" method="post">
                <button type="submit" class="btn-deconnexion">🚪 Se déconnecter</button>
            </form>
        </div>
    </div>
</body>
</html>
