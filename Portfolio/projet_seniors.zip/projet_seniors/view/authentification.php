<?php session_start(); ?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        body {
            background-color: #4E8EF7;
        }

        .auth-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .auth-box {
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
        }

        .auth-box h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #5D3FD3;
        }

        .error-message {
            background-color: #ffe0e0;
            color: #a00000;
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div class="auth-container">
        <form class="auth-box" action="../controller/connexion.php" method="post">
            <h2>Connexion 👤</h2>

            <?php if (isset($_GET['erreur']) && $_GET['erreur'] === 'identifiants'): ?>
                <div class="error-message">❌ Identifiants incorrects</div>
            <?php endif; ?>

            <label for="mail">Email :</label>
            <input type="email" name="mail" required>

            <label for="mot_de_passe">Mot de passe :</label>
            <input type="password" name="mot_de_passe" required>

            <input type="submit" value="Se connecter">
        </form>
    </div>
</body>
</html>
