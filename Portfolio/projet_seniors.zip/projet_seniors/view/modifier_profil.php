<?php
session_start();
require_once(__DIR__ . '/../config/bdd.php');
require_once(__DIR__ . '/../model/utilisateur.php');

if (!isset($_SESSION['id_utilisateur']) || $_SESSION['role'] !== 'senior') {
    header('Location: authentification.php');
    exit();
}

$id = $_SESSION['id_utilisateur'];
$profil = getProfil($pdo, $id);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Modifier mon profil</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<div class="container">
    <div class="box">
        <h2>✏️ Modifier mon profil</h2>

        <form action="../controller/modifier_profil.php" method="post">
            <label for="pseudo">Pseudo :</label>
            <input type="text" name="pseudo" value="<?= htmlspecialchars($profil['pseudo'] ?? '') ?>" required>

            <label for="photo">URL de la photo :</label>
            <input type="text" name="photo" value="<?= htmlspecialchars($profil['photo'] ?? '') ?>">

            <label for="description">Description :</label>
            <textarea name="description" rows="3"><?= htmlspecialchars($profil['description'] ?? '') ?></textarea>

            <label for="situation">Situation familiale :</label>
            <input type="text" name="situation" value="<?= htmlspecialchars($profil['situation'] ?? '') ?>">

            <label for="centres_interet">Centres d’intérêt :</label>
            <input type="text" name="centres_interet" value="<?= htmlspecialchars($profil['centres_interet'] ?? '') ?>">

            <input type="submit" value="💾 Enregistrer">
        </form>

        <a href="espace_senior.php" class="btn-deconnexion">⬅ Retour</a>
    </div>
</div>
</body>
</html>
