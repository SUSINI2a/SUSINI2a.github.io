<?php
session_start();
if (!isset($_SESSION['id_utilisateur']) || $_SESSION['role'] !== 'senior') {
    header('Location: authentification.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Espace Senior</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
    <div class="container">
        <div class="box">
            <h1>Bienvenue, <?= htmlspecialchars($_SESSION['pseudo']) ?> 👋</h1>

            <ul>
                <li><a class="nav-link" href="evenement.php">Voir les événements</a></li>
                <li><a class="nav-link" href="../controller/agenda.php">📅 Mon agenda</a></li>
                <li><a class="nav-link" href="messagerie.php">💬 Messagerie</a></li>
                <li><a class="nav-link" href="modifier_profil.php">✏️ Modifier mon profil</a></li>
            </ul>

            <form action="deconnexion.php" method="post">
                <button type="submit" class="btn-deconnexion">🚪 Se déconnecter</button>
            </form>
        </div>
    </div>
</body>
</html>
