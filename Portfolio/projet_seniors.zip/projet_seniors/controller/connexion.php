<?php
session_start();
require_once(__DIR__ . '/../config/bdd.php');
require_once(__DIR__ . '/../model/utilisateur.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $mail = trim($_POST['mail']);
    $mot_de_passe = $_POST['mot_de_passe'];

    $utilisateur = getUtilisateurByMail($pdo, $mail);

    if ($utilisateur && password_verify($mot_de_passe, $utilisateur['mot_de_passe'])) {
        $_SESSION['id_utilisateur'] = $utilisateur['id_utilisateur'];
        $_SESSION['pseudo'] = $utilisateur['prenom'];
        $_SESSION['role'] = $utilisateur['role'];

        if ($utilisateur['role'] === 'admin') {
            header('Location: ../view/espace_admin.php');
        } else {
            header('Location: ../view/espace_senior.php');
        }
        exit();
    } else {
        header('Location: ../view/authentification.php?erreur=identifiants');
        exit();
    }
} else {
    header('Location: ../view/authentification.php');
    exit();
}
