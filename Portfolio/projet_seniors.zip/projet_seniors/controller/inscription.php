<?php
session_start();
require_once(__DIR__ . '/../config/bdd.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = trim($_POST['nom']);
    $prenom = trim($_POST['prenom']);
    $date_naissance = $_POST['date_naissance'];
    $mail = trim($_POST['mail']);
    $mot_de_passe = $_POST['mot_de_passe'];
    $ville = trim($_POST['ville']);
    $role = $_POST['role'];

    // Vérification du rôle (sécurité)
    if (!in_array($role, ['senior', 'admin'])) {
        header('Location: ../view/admin_utilisateurs.php?erreur=role');
        exit();
    }

    // Vérifier si l’utilisateur existe déjà
    $stmt = $pdo->prepare("SELECT * FROM utilisateur WHERE mail = :mail");
    $stmt->execute(['mail' => $mail]);
    if ($stmt->fetch()) {
        // Redirection selon l'origine
        if (isset($_SESSION['id_utilisateur']) && $_SESSION['role'] === 'admin') {
            header('Location: ../view/admin_utilisateurs.php?erreur=mail');
        } else {
            header('Location: ../view/authentification.php?erreur=mail');
        }
        exit();
    }

    // Hachage du mot de passe
    $hash = password_hash($mot_de_passe, PASSWORD_DEFAULT);

    // Insertion
    $sql = "INSERT INTO utilisateur (nom, prenom, date_naissance, mail, mot_de_passe, ville, role)
            VALUES (:nom, :prenom, :date_naissance, :mail, :mot_de_passe, :ville, :role)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        'nom' => $nom,
        'prenom' => $prenom,
        'date_naissance' => $date_naissance,
        'mail' => $mail,
        'mot_de_passe' => $hash,
        'ville' => $ville,
        'role' => $role
    ]);

    // Redirection selon le contexte
    if (isset($_SESSION['id_utilisateur']) && $_SESSION['role'] === 'admin') {
        header('Location: ../view/admin_utilisateurs.php?success=1');
    } else {
        header('Location: ../view/authentification.php?success=1');
    }
    exit();
} else {
    header('Location: ../view/authentification.php');
    exit();
}
