<?php
session_start();
require_once(__DIR__ . '/../config/bdd.php');

if (!isset($_SESSION['id_utilisateur']) || $_SESSION['role'] !== 'senior') {
    header('Location: ../view/form_connexion.php');
    exit();
}

$id_emetteur = $_SESSION['id_utilisateur'];
$id_destinataire = $_POST['id_destinataire'] ?? null;
$contenu = trim($_POST['contenu'] ?? '');

if (!$id_destinataire || empty($contenu)) {
    header("Location: ../view/messagerie.php?erreur=champ_vide");
    exit();
}

$stmt = $pdo->prepare("SELECT id_utilisateur FROM utilisateur WHERE id_utilisateur = :id AND role = 'senior'");
$stmt->execute(['id' => $id_destinataire]);

if (!$stmt->fetch()) {
    header("Location: ../view/messagerie.php?erreur=destinataire");
    exit();
}

$insert = $pdo->prepare("INSERT INTO message (contenu, date_heure, id_emetteur, id_destinataire)
                         VALUES (:contenu, NOW(), :emetteur, :destinataire)");
$insert->execute([
    'contenu' => $contenu,
    'emetteur' => $id_emetteur,
    'destinataire' => $id_destinataire
]);

header('Location: ../view/messagerie.php?success=1');
exit();
