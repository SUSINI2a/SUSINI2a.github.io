<?php
session_start();
require_once(__DIR__ . '/../config/bdd.php');
require_once(__DIR__ . '/../model/utilisateur.php');

if (!isset($_SESSION['id_utilisateur']) || $_SESSION['role'] !== 'senior') {
    header('Location: ../view/form_connexion.php');
    exit();
}

$id = $_SESSION['id_utilisateur'];

$pseudo = trim($_POST['pseudo']);
$photo = trim($_POST['photo']);
$description = trim($_POST['description']);
$situation = trim($_POST['situation']);
$centres_interet = trim($_POST['centres_interet']);

// On regarde si un profil existe déjà :
$profil = getProfil($pdo, $id);

if ($profil) {
    mettreAJourProfil($pdo, $id, $pseudo, $photo, $description, $situation, $centres_interet);
} else {
    creerProfil($pdo, $id, $pseudo, $photo, $description, $situation, $centres_interet);
}

// On met à jour la session pour afficher le nouveau pseudo
$_SESSION['pseudo'] = $pseudo;

// Redirection vers l’espace senior
header('Location: ../view/espace_senior.php?profil=modifie');
exit();
