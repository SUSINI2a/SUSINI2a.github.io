<?php
session_start();
require_once(__DIR__ . '/../config/bdd.php');

if (!isset($_SESSION['id_utilisateur']) || $_SESSION['role'] !== 'senior') {
    header('Location: ../view/form_connexion.php');
    exit();
}

$id_utilisateur = $_SESSION['id_utilisateur'];
$id_evenement = $_POST['id_evenement'] ?? null;

if ($id_evenement) {
    $check = $pdo->prepare("SELECT * FROM participation WHERE id_utilisateur = :uid AND id_evenement = :eid");
    $check->execute(['uid' => $id_utilisateur, 'eid' => $id_evenement]);

    if ($check->fetch()) {
        header("Location: ../view/evenement.php?erreur=deja_inscrit");
        exit();
    }

    $insert = $pdo->prepare("INSERT INTO participation (id_utilisateur, id_evenement, date_inscription)
                             VALUES (:uid, :eid, CURRENT_DATE)");
    $insert->execute([
        'uid' => $id_utilisateur,
        'eid' => $id_evenement
    ]);

    header("Location: ../view/evenement.php?success=1");
    exit();
} else {
    header("Location: ../view/evenement.php?erreur=manquant");
    exit();
}
