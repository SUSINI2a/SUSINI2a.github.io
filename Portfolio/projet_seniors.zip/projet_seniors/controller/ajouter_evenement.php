<?php
session_start();
require_once(__DIR__ . '/../config/bdd.php');
require_once(__DIR__ . '/../model/evenement.php');

if (!isset($_SESSION['id_utilisateur']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../view/authentification.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'titre' => $_POST['titre'],
        'description' => $_POST['description'],
        'lieu' => $_POST['lieu'],
        'date_heure' => $_POST['date_heure'],
        'type' => $_POST['type'],
        'nb_max_participants' => intval($_POST['nb_max_participants']),
    ];

    ajouterEvenement($pdo, $data);

    header('Location: ../view/admin_evenements.php?success=1');
    exit();
} else {
    header('Location: ../view/form_ajouter_evenement.php');
    exit();
}
