<?php
session_start();
require_once(__DIR__ . '/../config/bdd.php');
require_once(__DIR__ . '/../model/evenement.php');

if (!isset($_SESSION['id_utilisateur']) || $_SESSION['role'] !== 'senior') {
    header('Location: authentification.php');
    exit();
}

$evenements = getEvenementsInscrits($pdo, $_SESSION['id_utilisateur']);
include(__DIR__ . '/../view/agenda.php');
