# 📄 Rapport d'avancement – Projet Yams

## 1. 🧭 Rappel des objectifs

- Objectif 1 : Yams solo jouable sur ligne de commande
- Objectif 2 : Yams duo avec adversaire IA ou humain
- Ce rapport fait le point sur l'avancement à la fin de la première période.


## 2. ✅ Tâches effectuées

### Objectif 1 – Yams solo
- Analyse du code fourni :
  - Le code de base manquer des 7 combinaisons majeure du jeu, il n'y avait que 2 combinaisons, donc 2 tours alors qu'il fallait 7 tours pour que le jeu soit complet, il y avait plusieurs erreurs de logique ou de gestion dans les listes par exemple, le random qui était mal utilisé sur Dice. 
- Cahier des charges :
  - Avoir toutes les combinaisons majeures (7)
  - Corriger les boucles, les relances, liste
  - S'assurer de la vérification des combinaisons avant de donner des points
- Programmation :
  - Création de nouvelles classes de combinaisons (Carre, PetiteSuite, GrandeSuite, Chance, YamsCombination). 
  - Correction de Board, Dice, Combination, ScoreSheet
- Livrable :
  - Projet complètement jouable en solo sur 7 tours
  - Chaque combinaison est correctement vérifiée et fonctionel
  - Scores affichés clairements

### Objectif 2 – Yams duo
- Analyse :
  - Pas de gestion pour multi joueur, ou IA.
- Cahier des charges et architecture envisagée :
  - Crée une nouvelle classe YamsDuo
  - Gestion de deux joueurs humain ou IA
  - IA simple capable de lancer les dés et choisir la meilleure combinaisons disponible.
- Programmation :
  - développement de la classe YamsDuo
  - IA
  - gestion des joueurs
- Livrable :
  - Mode duo fonctionnel
    - Humain vs Humain
    - Humain vs IA


## 3. 🧩 Organisation du groupe

- Répartition des tâches :
  - Piyush BHATT: Correction du code fourni du mode solo, création des combinaisons, yams duo et ia.
  - Charles Susini: participation à l'analyse, rédaction des rapports, et réalisation des tests et validation finale.
- Outils utilisés :
  - Eclipse pour le développement JAVA
  - Discord pour la communication
  - Google doc pour la rédaction


## 4. ⚠️ Difficultés rencontrées

- Techniques :  
  - Difficulté a comprendre les erreurs dans le code
  - Gestion des joueurs, et des tours avec les alternance entre joueurs et IA
  - L'organisation des fichiers mais surtout la configuration d'eclipse
- Organisationnelles :  
  - gestion du temps compliqué (pas de contact pendant 1semaine)
  - synchronisation des tests et correction pour le faire en distance


## 5. 🔭 Pistes d’amélioration du jeu

Listez ici les idées d’évolution que vous souhaiteriez intégrer dans les objectifs 3+.

- Idée 1 : Un bouton rejouer la partie à la fin
- Idée 2 : Un meilleur affichage ou crée un écran a part avec peut être javafx
- Idée 3 : Ajouter une sauvegarde et une pause un peu comme sur le jeu tetris Python


## 6. 🎯 Objectifs 3+ envisagés

- Propositions d’objectifs à développer (techniquement réalistes dans le temps imparti) :
  - nouvelles combinaisons, IA plus avancée, sauvegarde des scores, etc.

