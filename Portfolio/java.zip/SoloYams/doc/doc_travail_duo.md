# 🧩 Document de Travail – Développement d’un Yams Duo

**Noms des étudiants : Piyush BHATT, Charles SUSINI**  
**Date :27/04/2025**


## ✨ Tâche a. – Analyse du Code Produit pour l’Objectif 1

### 1. Démarche suivie  
J'ai repris certains mécanique de la partie solo comme par exemple les mécanique principales d'un tour de jeu (lancers, relances, choix de la combinaison). Ensuite, j'ai chercher à comment ajouter un deuxième joueur et une IA donc avoir 2 scoreboard, une gestion différente que celle du jeu mode solo, pouvoir choisir quelle mode on veut au début etc. 

### 2. Liste des éléments réutilisables

> Indiquez ici ce qui peut rester inchangé ou être réutilisé tel quel dans la version duo.

- [ ] Classe `Dice`  
- [ ] Classe `Board`
- [ ] Interface `Combination` et ses implémentations (`FullHouse`, `ThreeOfAKind`,etc)
- [ ] Classe `ScoreSheet`
- [ ] Mécanique des relances et choix de combinaisons du mode solo qui sont les mêmes.


### 3. Liste des manques par rapport à un Yams duo

> Listez ici les fonctionnalités ou éléments manquants pour avoir un jeu jouable à deux, humain ou IA.

- 🔲 Gestion de deux joueurs  
- 🔲 Changer des tours humain/humain ou humain/IA
- 🔲 IA capable de jouer automatiquement sans interaction humaine
- 🔲 Choix du mode au début du jeu: Humain duo ou IA
- 🔲 Affichage des score séparé pour les deux joueurs 'scoreboard'

## 🛠️ Tâche b. – Proposition de Solution

### 1. Cahier des charges simplifié

> Listez les fonctionnalités que vous comptez développer ou modifier.

- [ ] Permettre à deux joueurs de jouer à tour de rôle  
- [ ] Ajouter un ScoreSheet séparés pour les 2 joueurs
- [ ] Créer un choix au début de la partie pour le mode duo ou IA
- [ ] Programmer une IA simple pour lancer des dés et choisir une combinaisons
- [ ] Afficher les scores de chaque joueurs après chaque round


### 2. Choix techniques importants

> Décrivez ici vos grandes orientations de conception.

- créations d'une nouvelle classe `YamsDuo.java` différente de Yams.java
- réutilisation de board, dice, combination, scoresheet sans dupliquer
- gestion dynamique du mode choisi (humain duo ou IA)
- pour l'ia ajout d'une logique simple pour relancer au hasard et choisir la meilleure combinaison disponible.
- affichage de score tout par tour bien spéarer pas de mélange de scoresheet

### 3. Schéma simple de l’organisation du programme

```
Yams (main - duo)
 ├── Board
      └── Dice x5
 ├── ScoreSheet (x2)
 ├── IA intégrée dans YamsDuo
 └── Combination (interface)
       ├── FullHouse
       ├── ThreeOfAKind
       └── Carre
       └── PetiteSuite
       └── GrandeSuite
       └── Chance
       └── YamsCombination
```

---

## 💻 Tâche c. – Programmation

> Détaillez les ajouts/modifications apportés au code.

- Ajouts : `Classes YamsDuo.java` créée entièrement pour gérer le mode duo ou IA et la fonction isChooseCombination(Board board, ScoreSheet, iaScoreSheet) pour les choix de l'IA
- Modifications : Aucune modification apporté sur les classes du mode solo (Dice, Board, Combination etc)
- Tests réalisés : Test complet mode duo avec choix du mode au début, les noms des joueurs, lancement des dés, choix de la combinaisons, les mêmes tests ont était réalisé pour l'IA.


## 📦 Tâche d. – Livraison

> Cochez ce qui a été fait.

 
- [ ] Partie jouable en ligne de commande à deux joueurs  
- [ ] Ce document rempli
- [ ] fichier source ajouté dans src/fr/uge/yams/


## ✍️ Commentaire personnel 

> Vous pouvez écrire ici ce que vous avez appris, aimé ou trouvé difficile dans cette version duo.

J'ai appris a gérer plusieurs types de joueurs, a bien séparer et structurer le code. La partie IA m'as surpris je pensais que ce serait beaucoup plus compliqué que prévu mais en soit pour le lancement du dés c'est du random et pour les choix il faut juste qu'elle choisie la plus intelligente, donc plus de peur que de mal. En bref ce projet m'as appris a bien structurer l'organisations de mes fichiers, a comprendre certaines erreurs et surtout identifier ses erreurs, surtout les erreurs de logiques comme par exemple ne pas donnés des points avant même d'avoir pu vérifier si la personne a marqué les points en questions.