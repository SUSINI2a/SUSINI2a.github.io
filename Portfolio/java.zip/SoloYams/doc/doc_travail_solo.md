# 🧩 Document de Travail – Développement d’un Yams Solo

**Noms des étudiants : Piyush BHATT, Charles SUSINI**  
**Date :27/04/2025**


## ✨ Tâche a. – Analyse du Code Existant

### 1. Démarche suivie  
J'ai commencer en regardant les fichiers fourni, yams.java, border, dice etc.. Puis j'ai essayer de lancer yams pour voir quelle erreurs allait apparaitre, il y en a eu plusieurs que ce soit sur les côtés du dé qui manque par exemple sur Border on commencer avec 1 au lieu de 0 donc ça fausser la liste, plusieurs erreurs de ce type. Et les parties qui manquer c'est a dire les figures majeurs on en avait que 2 sur 7.

### 2. Liste des fonctionnalités déjà implémentées

- [X] Affichage des dés  
- [X] Relance d’un dé  
- [X] Choix d'une combinaison (brelan ou Full House)
- [X] Calcul de score partiel (sans vérification réelle)s

### 3. Liste des manques

> Identifiez ce qui manque pour que le Yams soit complet et jouable correctement en solo.

- 🔲 pas de vériciation sur la combinaison choisie pour réalisée les dés triés
- 🔲 gestion incomplète: seulement 2 combinaison disponibles 
- 🔲 partie limité a 2 tour au lieu de 7 
- 🔲 pas de blocage pour empêcher de choisir deux fois la même combinaison.
- 🔲 affichage des scores directement et pas très lisible

## 🛠️ Tâche b. – Proposition de Solution

### 1. Cahier des charges simplifié

> Listez ici les fonctionnalités que vous comptez ajouter ou améliorer.
 
- [ ] Permettre de relancer plusieurs dés à la fois  
- [ ] ajouter toutes les combinaisons majeure: Brelan, Carré, Full, Petite suite, Grande suite, Chance, Yams.
- [ ] vérifier que la combinaison est réalisable avant de donner les points (référence au return 25 point et 15 points tout au début des méthodes)
- [ ] empêcher de jouer la même combinaison
- [ ] faire 7 tours complet au lieu de 2 (1 combinaison par tour)
- [ ] afficher le score plus proprement et clairement

### 2. Choix techniques importants

> Expliquez ici brièvement comment vous comptez vous y prendre techniquement (nouvelle classe, refactorisation, etc.)

- On crée de nouvelle classe pour les combinaison (carré, petite suite, grande suite, chance, yams combination)
- correction de scoresheet pour vérifier si une combinaison a déjà été jouée (isUsed())
- simplifier combination pour forcer toutes les combinaisons à définir la méthode score(Board)
- correction du board pour un accès clair aux valeurs des dés (getValues())  


### 3. Schéma simple de l’organisation du programme
```
Yams (main - solo)
 ├── Board
 │    └── Dice x5
 ├── ScoreSheet
 └── Combination (interface)
       ├── FullHouse
       └── ThreeOfAKind
       └── Carre
       └── PetiteSuite
       └── GrandeSuite
       └── Chance
       └── YamsCombination
```

---

## 💻 Tâche c. – Programmation

> Listez ici les classes ou méthodes que vous avez créées ou modifiées pour répondre au cahier des charges.

- Création : Classes: Carre, PetiteSuite, GrandeSuite, Chance, YamsCombination
- Modification : Board.java (boucle et accès aux valeurs), Combination.java (suppression du default inutile), ScoreSheet.java (méthode isUsed() et affichage clair), ThreeOfAKind.java et FullHouse.java (ajout de vérifications) 
- Tests réalisés : Le jeu complet sur 7 tours avec enchaînement des combinaisons, choix sécurisé, score final affiché sans crash.


## 📦 Tâche d. – Livraison

> Vérifiez que tout est prêt pour la livraison.

- [ ] Code fonctionnel  
- [ ] Partie ligne de commande jouable sur 7 tours  
- [ ] Combinaisons jouables au choix (et pas deux fois !)  
- [ ] Affichage du score total  
- [ ] Ce document rempli  


## ✍️ Commentaires personnels 

> Vous pouvez expliquer ici ce que vous avez appris, aimé ou trouvé difficile dans l’exercice.

J'ai appris a lire certaines erreurs, a mieux comprendre la structure d'un code et a repérer des erreurs, et pouvoir coder derrière quuelqu'un et comprendre l'importance des commentaires.
