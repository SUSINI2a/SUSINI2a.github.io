package fr.uge.yams;

import java.util.ArrayList;

public class Board {

	private final ArrayList<Dice> fiveDice = new ArrayList<Dice>();

	public Board() {
		for (var i = 0; i < 5; i++) {  //correction du <=5 car on veut pas d'égale mais de chiffre précis
			fiveDice.add(new Dice());
		}
	}
// On change le i=1 en i=0 car une boucle classique pour une liste commence par i=0 jusqu'a < n
	@Override
	public String toString() {
		var builder = new StringBuilder();
		for (var i = 0; i < 5; i++) {
			builder.append(fiveDice.get(i).toString()); //on enlève le -1 car au lieu de se déplacer avec un -1 dans la liste on le fait directement depuis le i
		}
		builder.append("\n").append("-----------------\n");

		return builder.toString();
	}

	public void reroll(int pos) {
		if (pos < 1 || pos > 5) {
			throw new IllegalArgumentException();
		}
		fiveDice.set(pos - 1, new Dice());
	}

	public ArrayList<Integer> getValues() {    //supprimer le main void et ajout de l'arraylist car les combinaisons (fullhouse ou threeofakind) doivent accéder aux valeurs des dès pour analyser le score.
        var values = new ArrayList<Integer>();
        for (var die : fiveDice) {
            values.add(die.value());
        }
        return values;
	}
}
