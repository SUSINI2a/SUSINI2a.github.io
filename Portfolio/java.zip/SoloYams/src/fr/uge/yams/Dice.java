package fr.uge.yams;

import java.util.Random;

public record Dice(int value) {

	public Dice {
		if (value > 6 || value < 1) {
			throw new IllegalArgumentException();
		}
	}

	public Dice() {
		this(new Random().nextInt(6) + 1); // changement ici au lieu de 5 on met 6 pour avoir entre 1 et 6 car un dée a 6 faces et avec 5 on pouvait pas avoir 6
	}

	public Dice reroll() {
		return new Dice();
	}

	@Override
	public String toString() {
		return "-------\n" + "|  " + value + "  |\n" + "-------\n";
	}

}
