package fr.uge.yams;

public interface Combination {
	
	int score(Board board);   // supprimer le default et le return on ne fournit pas de valeur par défault car chaque combinaisons doit obligatoirement redéfinir score on force l'implémentation 
}
