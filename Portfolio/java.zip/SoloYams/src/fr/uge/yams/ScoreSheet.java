package fr.uge.yams;

import java.util.HashMap;
import java.util.Objects;

public class ScoreSheet {

	private final HashMap<Combination, Integer> scoreMap = new HashMap<>();

	public void updateScore(Combination pattern, Board board) {
		Objects.requireNonNull(pattern);
		if (scoreMap.containsKey(pattern)) {
			throw new IllegalArgumentException("already a score for this combination");
		}
		scoreMap.put(pattern, pattern.score(board));
	}

	public boolean isUsed(Combination combination) {  // ajout nouvelle méthode qui vient remplacer le toString pour un affichage plus propre et isUsed vient vérifier si une combinaison a déjà était jouée ce qui évite d'avoir de la triche ou erreur. 
		return scoreMap.containsKey(combination);
	}
	
	public int scoreTotal() {
		return scoreMap.values().stream().mapToInt(Integer::intValue).sum();
	}

	@Override
	public String toString() {        // ajout 
        var builder = new StringBuilder();
        for (var entry : scoreMap.entrySet()) {
            builder.append(entry.getKey()).append(" : ").append(entry.getValue()).append(" points\n");
        }
        return builder.toString();
	}

}
