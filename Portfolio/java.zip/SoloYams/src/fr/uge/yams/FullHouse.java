package fr.uge.yams;

import java.util.HashMap;

public record FullHouse() implements Combination {

	@Override
	 public int score(Board board) {    // on vérifie avant si ça fait bien 3 dés et 2 dés identiques avant de donnés 25pts on peut pas direct donnés
        var counts = new HashMap<Integer, Integer>();
        for (var value : board.getValues()) {
            counts.put(value, counts.getOrDefault(value, 0) + 1);
        }
        return counts.containsValue(3) && counts.containsValue(2) ? 25 : 0;
	}

	@Override
	public String toString() {
		return "Full House";
	}

}
