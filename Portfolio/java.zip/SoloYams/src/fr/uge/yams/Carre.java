package fr.uge.yams;

import java.util.HashMap;

public record Carre() implements Combination {

    @Override
    public int score(Board board) {
        var counts = new HashMap<Integer, Integer>();
        for (var value : board.getValues()) {
            counts.put(value, counts.getOrDefault(value, 0) + 1);
        }
        return counts.containsValue(4) || counts.containsValue(5) ? 30 : 0;
    }

    @Override
    public String toString() {
        return "Carré";
    }
}
