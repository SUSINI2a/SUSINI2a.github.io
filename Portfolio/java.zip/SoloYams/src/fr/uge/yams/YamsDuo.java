package fr.uge.yams;

import java.util.Random;
import java.util.Scanner;

public class YamsDuo {

    private static String initPlayer(Scanner scanner, int playerNumber) {
        System.out.println("Enter the name of player " + playerNumber + ":");
        return scanner.nextLine();
    }

    private static int askReroll(Scanner scanner) {
        while (true) {
            System.out.println("Do you want to reroll a die? Type 0 for no, 1-5 to reroll this die.");
            try {
                var choice = Integer.parseInt(scanner.nextLine());
                if (choice >= 0 && choice <= 5) {
                    return choice;
                }
            } catch (NumberFormatException ignored) {}
            System.out.println("Invalid input, please try again.");
        }
    }

    private static String askCombination(Scanner scanner) {
        System.out.println("Please choose a combination to score in your score sheet by entering its first letter.");
        return scanner.nextLine().trim().toUpperCase();
    }

    private static Combination parseCombination(String combinationName) {
        return switch (combinationName) {
            case "T" -> new ThreeOfAKind();
            case "F" -> new FullHouse();
            case "C" -> new Carre();
            case "P" -> new PetiteSuite();
            case "G" -> new GrandeSuite();
            case "H" -> new Chance();
            case "Y" -> new YamsCombination();
            default -> throw new IllegalArgumentException("Unexpected value: " + combinationName);
        };
    }

    private static Combination iaChooseCombination(Board board, ScoreSheet iaScoreSheet) {
        var available = new Combination[]{
                new ThreeOfAKind(), new FullHouse(), new Carre(),
                new PetiteSuite(), new GrandeSuite(), new Chance(), new YamsCombination()
        };
        for (var comb : available) {
            if (!iaScoreSheet.isUsed(comb) && comb.score(board) > 0) {
                return comb;
            }
        }
        for (var comb : available) {
            if (!iaScoreSheet.isUsed(comb)) {
                return comb;
            }
        }
        return new Chance();
    }

    public static void main(String[] args) {
        var scanner = new Scanner(System.in);
        System.out.println("Choose mode: 1 - Human vs Human | 2 - Human vs AI");
        int mode;
        while (true) {
            try {
                mode = Integer.parseInt(scanner.nextLine());
                if (mode == 1 || mode == 2) {
                    break;
                }
            } catch (NumberFormatException ignored) {}
            System.out.println("Invalid input, please enter 1 or 2.");
        }

        var player1Name = initPlayer(scanner, 1);
        String player2Name;
        boolean iaMode = false;
        if (mode == 1) {
            player2Name = initPlayer(scanner, 2);
        } else {
            player2Name = "AI";
            iaMode = true;
        }

        var player1ScoreSheet = new ScoreSheet();
        var player2ScoreSheet = new ScoreSheet();

        for (var roundCounter = 0; roundCounter < 7; roundCounter++) {
            System.out.println("Round " + (roundCounter + 1) + " - " + player1Name + "'s turn");
            var board1 = new Board();
            System.out.println(board1);
            for (var updateCounter = 0; updateCounter < 2; updateCounter++) {
                var choice = askReroll(scanner);
                if (choice > 0) {
                    board1.reroll(choice);
                    System.out.println(board1);
                } else {
                    break;
                }
            }
            while (true) {
                try {
                    var combinationChoice = parseCombination(askCombination(scanner));
                    if (player1ScoreSheet.isUsed(combinationChoice)) {
                        System.out.println("This combination has already been used. Choose another one.");
                    } else {
                        player1ScoreSheet.updateScore(combinationChoice, board1);
                        break;
                    }
                } catch (IllegalArgumentException e) {
                    System.out.println("Invalid choice. Please enter T, F, C, P, G, H, or Y.");
                }
            }

            System.out.println("Round " + (roundCounter + 1) + " - " + player2Name + "'s turn");
            var board2 = new Board();
            System.out.println(board2);

            if (iaMode) {
                var random = new Random();
                for (var updateCounter = 0; updateCounter < 2; updateCounter++) {
                    if (random.nextBoolean()) {
                        int rerollChoice = random.nextInt(5) + 1;
                        board2.reroll(rerollChoice);
                    }
                }
                var iaCombination = iaChooseCombination(board2, player2ScoreSheet);
                player2ScoreSheet.updateScore(iaCombination, board2);
                System.out.println("The AI chose: " + iaCombination);
            } else {
                for (var updateCounter = 0; updateCounter < 2; updateCounter++) {
                    var choice = askReroll(scanner);
                    if (choice > 0) {
                        board2.reroll(choice);
                        System.out.println(board2);
                    } else {
                        break;
                    }
                }
                while (true) {
                    try {
                        var combinationChoice = parseCombination(askCombination(scanner));
                        if (player2ScoreSheet.isUsed(combinationChoice)) {
                            System.out.println("This combination has already been used. Choose another one.");
                        } else {
                            player2ScoreSheet.updateScore(combinationChoice, board2);
                            break;
                        }
                    } catch (IllegalArgumentException e) {
                        System.out.println("Invalid choice. Please enter T, F, C, P, G, H, or Y.");
                    }
                }
            }

            System.out.println("\nScore after Round " + (roundCounter + 1) + ":");
            System.out.println(player1Name + "'s score:\n" + player1ScoreSheet);
            System.out.println(player2Name + "'s score:\n" + player2ScoreSheet);
        }

        System.out.println("\nGame Over!");
        System.out.println(player1Name + " final score: " + player1ScoreSheet.scoreTotal() + " points.");
        System.out.println(player2Name + " final score: " + player2ScoreSheet.scoreTotal() + " points.");
    }
}

