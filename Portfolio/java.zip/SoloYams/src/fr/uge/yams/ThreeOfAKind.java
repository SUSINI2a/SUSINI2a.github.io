package fr.uge.yams;

import java.util.HashMap;

public record ThreeOfAKind() implements Combination {

	@Override
	public int score(Board board) { //la même erreur que dans fullhouse, avant de pouvoir attribuer 15pts faut vérifier si on a bien fait 3 dés identiques minimum.
        var counts = new HashMap<Integer, Integer>();
        for (var value : board.getValues()) {
            counts.put(value, counts.getOrDefault(value, 0) + 1);
        }
        return counts.containsValue(3) || counts.containsValue(4) || counts.containsValue(5) ? 15 : 0;
	}

	@Override
	public String toString() {
		return "Three of A Kind";
	}
}
