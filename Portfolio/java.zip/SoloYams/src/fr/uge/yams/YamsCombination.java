package fr.uge.yams;

import java.util.HashMap;

public record YamsCombination() implements Combination {

    @Override
    public int score(Board board) {
        var counts = new HashMap<Integer, Integer>();
        for (var value : board.getValues()) {
            counts.put(value, counts.getOrDefault(value, 0) + 1);
        }
        return counts.containsValue(5) ? 50 : 0;
    }

    @Override
    public String toString() {
        return "Yams";
    }
}
