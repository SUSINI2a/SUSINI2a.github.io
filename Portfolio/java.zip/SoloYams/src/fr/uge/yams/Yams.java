package fr.uge.yams;

import java.util.Scanner;

public class Yams {

	public static String init(Scanner scanner) {
		System.out.println("Welcome, player, please enter your name.");
		return scanner.nextLine();

	}

	private static int askReroll(Scanner scanner) {
        while (true) {
            System.out.println("Do you want to reroll a die? Type 0 for no, 1-5 to reroll this die.");
            try {
                var choice = Integer.parseInt(scanner.nextLine());
                if (choice >= 0 && choice <= 5) {
                    return choice;
                }
            } catch (NumberFormatException ignored) {}
            System.out.println("Invalid input, please try again.");
        }
	}

	private static String askCombination(Scanner scanner) {
		System.out.println("Please choose a combination to score in your score sheet by entering its first letter.");
		return scanner.nextLine().trim().toUpperCase();
	}

	private static Combination parseCombination(String combinationName) {
		return switch (combinationName) {
		 case "T" -> new ThreeOfAKind();
         case "F" -> new FullHouse();
         case "C" -> new Carre();				// ajout de C, P, G, H, Y
         case "P" -> new PetiteSuite();
         case "G" -> new GrandeSuite();
         case "H" -> new Chance();
         case "Y" -> new YamsCombination();
		default -> throw new IllegalArgumentException("Unexpected value: " + combinationName);
		};
	}

	public static void main(String[] args) {
		var scanner = new Scanner(System.in);
		var name = init(scanner);
		System.out.println("Hello " + name + ", and good luck !\n");

		var scoreSheet = new ScoreSheet();
		// Début du tour du joueur
		// on passe de 2 tour a 7 tours comme indiqué sur le sujet yams se jouera avec 7 combinaisons majeure
		for (var roundCounter = 0; roundCounter < 7; roundCounter++) {
			System.out.println("Welcome in round " + (roundCounter + 1));
			var board = new Board();
			System.out.println(board);
			// Relances dans le tour
			// changer le 3 a 2
			for (var updateCounter = 0; updateCounter < 2; updateCounter++) {
				var choice = askReroll(scanner);
				if (choice > 0) {
					board.reroll(choice);
					System.out.println(board);
				} else {
					break;
				}
			}
			while (true) {
				try {
					var combinationChoice = parseCombination(askCombination(scanner));
					if (scoreSheet.isUsed(combinationChoice)) { // vérification de la combinaisons pour pas qu'elle soit choisie plus d'une fois
						System.out.println("This combination has already been used. Choose another one.");
					} else {
						 scoreSheet.updateScore(combinationChoice, board);
	                     break;
					}
				} catch (IllegalArgumentException e) {
					System.out.println("Invalid choice. Please enter T, F, C, P, G, H, or Y.");
				}
			}
			System.out.println(scoreSheet);
		}
        System.out.println("Game over! Your final score is: " + scoreSheet.scoreTotal() + " points.");
	}
}
