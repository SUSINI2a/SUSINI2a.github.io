package fr.uge.yams;

public record Chance() implements Combination {

    @Override
    public int score(Board board) {
        return board.getValues().stream().mapToInt(Integer::intValue).sum();
    }

    @Override
    public String toString() {
        return "Chance";
    }
}
