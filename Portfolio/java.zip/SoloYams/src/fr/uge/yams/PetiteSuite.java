package fr.uge.yams;

import java.util.HashSet;

public record PetiteSuite() implements Combination {

    @Override
    public int score(Board board) {
        var set = new HashSet<>(board.getValues());
        if (set.contains(1) && set.contains(2) && set.contains(3) && set.contains(4)) return 30;
        if (set.contains(2) && set.contains(3) && set.contains(4) && set.contains(5)) return 30;
        if (set.contains(3) && set.contains(4) && set.contains(5) && set.contains(6)) return 30;
        return 0;
    }

    @Override
    public String toString() {
        return "Petite Suite";
    }
}
