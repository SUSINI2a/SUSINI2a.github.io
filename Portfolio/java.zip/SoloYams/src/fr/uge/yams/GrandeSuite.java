package fr.uge.yams;

import java.util.HashSet;

public record GrandeSuite() implements Combination {

    @Override
    public int score(Board board) {
        var set = new HashSet<>(board.getValues());
        return (set.containsAll(java.util.List.of(1, 2, 3, 4, 5)) ||
                set.containsAll(java.util.List.of(2, 3, 4, 5, 6))) ? 40 : 0;
    }

    @Override
    public String toString() {
        return "Grande Suite";
    }
}
